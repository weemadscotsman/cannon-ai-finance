
import React, { useState, useEffect } from 'react';
import { ExpenseList } from './components/ExpenseList';
import { Planner } from './components/Planner';
import { LiveSession } from './components/LiveSession';
import { MediaHub } from './components/MediaHub';
import { SUPPORTED_CURRENCIES } from './constants';
import { Expense, ViewState, Currency } from './types';
import { speakText } from './services/geminiService';
import { StorageRegistry } from './services/storageRegistry';
import { calculateTotalMonthlyBurn } from './services/financeCore';

function App() {
  const [view, setView] = useState<ViewState>(ViewState.TRACKER);
  // Initialize from Storage
  const [expenses, setExpenses] = useState<Expense[]>(() => StorageRegistry.loadExpenses());
  const [currency, setCurrency] = useState<Currency>(() => StorageRegistry.loadCurrency());
  
  const [isBriefing, setIsBriefing] = useState(false);

  // Persistence Effects
  useEffect(() => {
    StorageRegistry.saveExpenses(expenses);
  }, [expenses]);

  useEffect(() => {
    StorageRegistry.saveCurrency(currency);
  }, [currency]);

  const handleAddExpense = (newExpense: Omit<Expense, 'id'>) => {
    const expenseWithId = { ...newExpense, id: crypto.randomUUID() };
    setExpenses(prev => [expenseWithId, ...prev]);
  };

  const handleEditExpense = (updatedExpense: Expense) => {
    setExpenses(prev => prev.map(e => e.id === updatedExpense.id ? updatedExpense : e));
  };

  const handleDeleteExpense = (id: string) => {
    setExpenses(prev => prev.filter(e => e.id !== id));
  }

  const handleBriefing = async () => {
    setIsBriefing(true);
    const total = calculateTotalMonthlyBurn(expenses);
    
    const summary = `Welcome to Cannon AI. Your calculated monthly burn is ${currency.symbol}${total.toFixed(0)}. You are tracking ${expenses.length} distinct data points. Stay sharp.`;
    
    const buffer = await speakText(summary);
    if (buffer) {
      const ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
      const source = ctx.createBufferSource();
      source.buffer = buffer;
      source.connect(ctx.destination);
      source.onended = () => setIsBriefing(false);
      source.start(0);
    } else {
      setIsBriefing(false);
    }
  };

  return (
    <div className="w-full h-screen bg-black text-white flex justify-center selection:bg-emerald-500/30">
        <div className="w-full max-w-lg h-full bg-[#050505] relative shadow-2xl flex flex-col border-x border-gray-900">
            
            <div className="h-20 flex items-center justify-between px-6 border-b border-gray-900 bg-black/80 backdrop-blur-xl z-20 shrink-0">
                <div>
                    <div className="flex items-center gap-2">
                        <h1 className="text-xl font-black tracking-tighter bg-clip-text text-transparent bg-gradient-to-r from-emerald-400 to-cyan-500">
                            CANN.ON.AI
                        </h1>
                        <div className="h-4 w-[1px] bg-gray-800"></div>
                        <span className="text-[9px] text-gray-500 font-black uppercase tracking-[0.2em] mt-0.5">FORGE</span>
                    </div>
                </div>
                
                <div className="flex items-center gap-3">
                    <button 
                        onClick={handleBriefing}
                        disabled={isBriefing}
                        className={`text-xs px-3 py-1.5 rounded-full font-bold border transition-all ${isBriefing ? 'bg-emerald-500 text-black border-emerald-400 animate-pulse' : 'bg-black text-emerald-400 border-emerald-900 hover:border-emerald-500'}`}
                    >
                        {isBriefing ? "BRIEFING..." : "🔊 STANDUP"}
                    </button>
                    <select 
                        value={currency.code}
                        onChange={(e) => {
                          const s = SUPPORTED_CURRENCIES.find(c => c.code === e.target.value);
                          if(s) setCurrency(s);
                        }}
                        className="bg-transparent border-none text-xs font-black text-gray-400 focus:ring-0 cursor-pointer"
                    >
                        {SUPPORTED_CURRENCIES.map(c => <option key={c.code} value={c.code}>{c.code}</option>)}
                    </select>
                </div>
            </div>

            <div className="flex-1 overflow-hidden relative">
                {view === ViewState.TRACKER && (
                  <ExpenseList 
                    expenses={expenses} 
                    currency={currency} 
                    onAdd={handleAddExpense} 
                    onEdit={handleEditExpense} 
                    onDelete={handleDeleteExpense} 
                  />
                )}
                {view === ViewState.PLANNER && <Planner currency={currency} expenses={expenses} />}
                {view === ViewState.LIVE && <LiveSession expenses={expenses} currency={currency} />}
                {view === ViewState.MEDIA && <MediaHub />}
            </div>

            <div className="h-24 absolute bottom-0 w-full bg-black/95 backdrop-blur-2xl border-t border-gray-900 flex justify-around items-center px-4 z-30 pb-6">
                <NavBtn active={view === ViewState.TRACKER} onClick={() => setView(ViewState.TRACKER)} icon="📊" label="Assets" />
                <NavBtn active={view === ViewState.PLANNER} onClick={() => setView(ViewState.PLANNER)} icon="🧠" label="Strategy" />
                
                <button 
                    onClick={() => setView(ViewState.LIVE)}
                    className={`mb-10 w-16 h-16 rounded-full flex items-center justify-center text-3xl shadow-2xl transition-all active:scale-95 ${view === ViewState.LIVE ? 'bg-white text-black scale-110' : 'bg-emerald-600 text-white hover:bg-emerald-500 shadow-emerald-500/20'}`}
                >
                    🎙️
                </button>
                
                <NavBtn active={view === ViewState.MEDIA} onClick={() => setView(ViewState.MEDIA)} icon="🛰️" label="IQ Hub" />
                <NavBtn active={view === ViewState.CHAT} onClick={() => setView(ViewState.TRACKER)} icon="⚙️" label="Forge" />
            </div>
        </div>
    </div>
  );
}

const NavBtn = ({ active, onClick, icon, label }: any) => (
    <button onClick={onClick} className={`flex flex-col items-center gap-1 w-14 transition-colors ${active ? 'text-emerald-400' : 'text-gray-600 hover:text-gray-400'}`}>
        <span className="text-xl">{icon}</span>
        <span className="text-[8px] font-black uppercase tracking-widest">{label}</span>
    </button>
);

export default App;
